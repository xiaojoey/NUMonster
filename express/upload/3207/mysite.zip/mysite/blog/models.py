from django.db import models

# each class is a table in the database. each varaible in the class is a column.
class Post(models.Model):
    title = models.CharField(max_length=140)
    body = models.TextField()
    date = models.DateTimeField()

    # metadata purposes, reference a specific post
    def __str__(self):
        return self.title
