from django.conf.urls import url, include
from . import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^contact/$', views.contact, name='contact')
]
# 1. this is the root of everything, checks urls. sees webapp, sees it has to include
# webapp.urls, so it goes to web app, opens webapp.urls
