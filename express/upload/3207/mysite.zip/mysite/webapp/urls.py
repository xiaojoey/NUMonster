from django.conf.urls import url
from . import views
# how do we control views to show? use the ontrolller, urls.py

urlpatterns = [
    url(r'^$', views.index, name='index')
]

#2. just came here from mysite urls.py page, now it sees this urls page. it goes
# through the urlpatterns, and sees the rgex that if something starts and ends,
# to show index, sowe show index. views.index
