from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.

#3. came to views.index from webapp urls.py, display the httpresponse 
def index(request):
    return HttpResponse("<h2>Hey!</h2>")
